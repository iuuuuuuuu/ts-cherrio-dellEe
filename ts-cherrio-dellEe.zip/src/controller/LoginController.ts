import 'reflect-metadata';

import { Controller, get } from './decorators';
import { Request, Response } from 'express';

interface BodyRequest extends Request {
  body: {
    [key: string]: string | undefined;
  };
}

@Controller
class LoginController {
  @get('/login')
  login() {}

  @get('/')
  home(req: BodyRequest, res: Response) {
    const isLogin = req.session ? req.session.login : false;
    if (isLogin) {
      res.send(`
      <!DOCTYPE html>
        <body>
        <a href='logout'>退出</a>
        </body>
      </html>
      `);
    } else {
      res.send(`
      <html>
        <body>
          <form method="post" action="/login">
              <input type="password" name="password">
              <button type="submit">登录</button>
          </form>
        </body>
      </html>
    `);
    }
  }
}

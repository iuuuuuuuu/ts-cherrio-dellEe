import { Router } from 'express';

const router = Router();

// 类装饰器
export function Controller(target: any) {
  console.log(target.__proto__, target.prototype);

  for (let key in target.prototype) {
    const path = Reflect.getMetadata('path', target.prototype, key);
    if (path) {
    }
  }
}
// 方法装饰器
export function get(path: string) {
  return function (target: any, key: string) {
    Reflect.defineMetadata('path', path, target, key);
    // router.get(path, target.prototype[key]);
    // console.log(path);
  };
}
